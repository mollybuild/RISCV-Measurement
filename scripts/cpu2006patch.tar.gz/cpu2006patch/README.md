## Apply toolset patch

Please apply the 5 patches with this document package.


## Build $SPEC/tools/src

1. You may need use PERLFLAGS like bellow, set it before running buildtools.

```
# without this flag, perl test numconvert.t will fail
$ export PERLFLAGS="-A ccflags=-fwrapv"

# fix undefined reference to pow, you may encounter
$ export PERLFLAGS="-A libs=-lm -A libs=-ldl -A libs=-lc -A ldflags=-lm -A cflags=-lm -A ccflags=-lm $PERLFLAGS"

# you may need specify lib path, otherwise perl DynaLoader.t may Failed
export PERLFLAGS="$PERLFLAGS -Dlibpth=/usr/lib/riscv64-linux-gnu"

```

## Install cpu2006

1. You need to specify SPEC_INSTALL_NOCHECK=1, ignore the failed of perl test toget through. Set this before running install.sh script.

```
$ export SPEC_INSTALL_NOCHECK=1 
```



