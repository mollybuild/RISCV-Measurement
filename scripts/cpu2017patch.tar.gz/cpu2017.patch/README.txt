1. src directory should be under $SPEC/tools:

```
$ cd $SPEC/install_archives
$ tar xvf tools-src.tar -C ../
```

2. please install pre-requisites:

```
$ sudo apt install perl
$ sudo apt install texinfo
```

3. replace the old config.guess and config.sub in following locations:

```
src/specinvoke/
src/specsum/build-aux/
src/tar-1.28/build-aux/
src/make-4.2.1/config/
src/rxp-1.5.0/
src/expat-2.1.0/conftools/
src/xz-5.2.2/build-aux/
```

download the new config.sub and config.guess

```
wget -O config.sub "git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.sub;hb=HEAD"
wget -O config.guess "git.savannah.gnu.org/gitweb/?p=config.git;a=blob_plain;f=config.guess;hb=HEAD"
```

4. apply the two pathces
